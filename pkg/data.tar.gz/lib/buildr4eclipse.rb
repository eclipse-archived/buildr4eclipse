
require File.dirname(__FILE__) + '/buildr4eclipse/tasks'
require File.dirname(__FILE__) + '/buildr4eclipse/lib'
require File.dirname(__FILE__) + '/buildr4eclipse/compiler'
